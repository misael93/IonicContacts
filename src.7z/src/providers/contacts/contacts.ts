import { Contacts, IContactProperties } from '@ionic-native/contacts';
import { Injectable } from '@angular/core';

@Injectable()
export class ContactsProvider {

  constructor(private _contacts: Contacts) { }

  getContacts(): Promise<IContactProperties[]> {
    return new Promise((resolve, reject) => {
      this._contacts.find(['*'])
        .then(contacts => {
          resolve(contacts);
        })
        .catch(err => {
          reject(err);
        });
    });
  }

}
